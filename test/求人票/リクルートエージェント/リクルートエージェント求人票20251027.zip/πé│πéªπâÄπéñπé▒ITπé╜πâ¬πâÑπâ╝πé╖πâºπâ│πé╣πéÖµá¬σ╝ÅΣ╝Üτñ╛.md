コウノイケＩＴソリューションズ株式会社

# 【システムエンジニア/web・オープン系】東証プライム上場Gｒ/自社内勤務

500〜600万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間125日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

東京都中央区新川2-3-1セントラルスクエア4F

業界未経験OK

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

★自社内勤務で、上流工程への挑戦をかなえられる求人です。 ■物流倉庫（WMS）事業や空港事業・メディカルなど幅広い業種を取り扱っている親会社の業務効率化システム開発にも挑戦可能！ ■年間休日125日/客先常駐なし/リモートワーク利用率100%/育休制度あり

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 職務内容

### ![](https://mypage.r-agent.com/_next/static/media/company.f695756d.svg)企業・求人の特色

■東証プライム上場・連結売上3000億円越えである鴻池運輸のグループ会社/鴻池運輸グループからの受注案件のため安定 ■案件の幅が広く、多種多様な業務の経験をすること可能！　■社員のリモートワーク利用率100％　■年間休日125日

### ![](https://mypage.r-agent.com/_next/static/media/note.135161c5.svg)仕事内容

鴻池運輸向けのシステム開発、顧客のDX推進を支援する業務効率化ソリューションの提案、プロジェクト開発を主にお任せいたします。 【具体的には】最初は開発業務からスタートし、意欲や適性に応じて上流工程にも早期から関わることが可能です。倉庫だけでなく、空港、メディカル、鉄鋼など多様な事業領域のシステム開発に携わることができます。 ゆくゆくは、鴻池運輸グループ企業向けのシステム構築業務のため、現場担当者と直接コミュニケーションを取りながら、要件定義から開発まで幅広く携わっていただきます。

### ![](https://mypage.r-agent.com/_next/static/media/experience.b0f16c1a.svg)求める能力・経験

【必須】■web・オープン系システムの開発経験　※自社内勤務で上流工程やマネジメントなどに挑戦した方歓迎。ご経験した開発スキルを活かして社内のSEをリーディングしていただける方。 ★当社で働く魅力★ ■連結売上3000億円以上を誇る鴻池運輸Gｒ向けの幅広い案件が安定受注。上流工程への挑戦も期待するため、スキルアップができる環境。 ■他社への常駐勤務なし・エンドユーザーとも直接連携可能な環境 ■社員のリモートワーク利用率100％（週1〜2日）・育休制度導入があるため、ワークライフバランスも大切にできる環境が整っております

学歴

高校、専修、短大、高専、大学、大学院

## 勤務条件

### ![](https://mypage.r-agent.com/_next/static/media/employ.e9939c19.svg)雇用形態

正社員（期間の定め：無）

試用期間

有 3ヶ月（試用期間中の勤務条件：変更無）

### ![](https://mypage.r-agent.com/_next/static/media/money.8ec98a5a.svg)給与

500万円～600万円 月給制 月給 360,000円～400,000円 月給￥360,000〜￥400,000 基本給￥360,000〜￥400,000を含む/月 ■賞与実績:年2回（7月、12月）

通勤手当

会社規定に基づき支給 6カ月定期運賃

### ![](https://mypage.r-agent.com/_next/static/media/working-time.c8e50ef1.svg)勤務時間

08時間00分 休憩45分

08:45～17:30

残業

有 平均残業時間：25時間

残業手当

有 残業時間に応じて別途支給

### ![](https://mypage.r-agent.com/_next/static/media/holiday.c0f9fa3c.svg)休日・休暇

年間 125日 内訳：完全週休二日制、土曜 日曜 祝日、年末年始5日

有給休暇

入社直後2日 最高付与日数10日 入社時期により2〜10日付与

### ![](https://mypage.r-agent.com/_next/static/media/heart.a433f583.svg)社会保険

健康保険：有 厚生年金：有 雇用保険：有 労災保険：有

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

変更の範囲：弊社の業務全般 【キャリアパス】 ・鴻池運輸のDXの先端IT技術者を目指せます。 ・初期配属の職場に留まらず、各事業部門の先端IT技術者として活躍頂くキャリアパスもあります。

最短２タップで完了!

応募する

興味なし

## 勤務地

### ![](https://mypage.r-agent.com/_next/static/media/position.3ff6801a.svg)配属先

### ![](https://mypage.r-agent.com/_next/static/media/relocation.5099e075.svg)転勤

無

### ![](https://mypage.r-agent.com/_next/static/media/map.9a33d316.svg)本社

住所

東京都中央区新川2-3-1セントラルスクエア4F

最寄駅

東京メトロ日比谷線茅場町駅 徒歩5分 JR京葉線八丁堀駅 徒歩5分 東京メトロ日比谷線八丁堀駅 徒歩5分

喫煙環境

敷地内全面禁煙

備考

変更の範囲：変更なし

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

勤務地の変更の範囲：当社の定める拠点全般

## 制度・福利厚生

### ![](https://mypage.r-agent.com/_next/static/media/heart-hand.782dcdb8.svg)制度

在宅勤務（全従業員利用可） リモートワーク可（全従業員利用可）

### ![](https://mypage.r-agent.com/_next/static/media/another.84c25cb6.svg)その他

寮・社宅

無

退職金

有

その他制度

テレワーク利用可（フルリモートは不可）、育児・介護休業、慶弔見舞金

### ![](https://mypage.r-agent.com/_next/static/media/note-heart.134d7562.svg)制度備考

【休日・休暇補足】 年間125日（2024年度） 夏季休日（8/14〜16） 年末年始休日（12/30〜1/3） 退職制度補足：勤続3年以上が支給対象 【福利厚生】 給湯設備あり 無料ウォーターサーバー、ソフトドリンク購入時補助あり


コウノイケＩＴソリューションズ株式会社

# 【システムエンジニア/web・オープン系】東証プライム上場Gｒ/自社内勤務

500〜600万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間125日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

東京都中央区新川2-3-1セントラルスクエア4F

業界未経験OK

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

★自社内勤務で、上流工程への挑戦をかなえられる求人です。 ■物流倉庫（WMS）事業や空港事業・メディカルなど幅広い業種を取り扱っている親会社の業務効率化システム開発にも挑戦可能！ ■年間休日125日/客先常駐なし/リモートワーク利用率100%/育休制度あり

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 選考内容

### ![](https://mypage.r-agent.com/_next/static/media/people.a9317f75.svg)採用人数

1名

### ![](https://mypage.r-agent.com/_next/static/media/interview.979de149.svg)面接回数

2回

### ![](https://mypage.r-agent.com/_next/static/media/papers.2b11ca07.svg)選考

筆記試験：無 1次：対面、最終：対面

## 企業概要

企業名

コウノイケＩＴソリューションズ株式会社

代表取締役

須田　敏夫

設立

2018年07月02日

従業員数

26名

資本金

80百万円

平均年齢

-

【KONOIKEグループとは】 ■世界各国にグループ会社を持ち、製造業・サービス業の請負や、航空輸送を含む物流サービスなど幅広い業界で活躍する企業集団。 【コウノイケITソリューションズ株式会社とは】 ■2018年7月に鴻池運輸株式会社と株式会社NSDが合併して誕生した当社は、ITプロフェショナル集団としてICTを活用した業務改善など、KONOIKEグループ内のシステム改革に取り組んでいます。 【主な事業目的】 ■KONOIKEグループ全社向けのシステム企画、設計、プロジェクト管理、導入展開 ■KONOIKEグループシステムエンジニア（SE）人材のAI・IoTなどの先端技術の習得 ■高品質なIoT、ロボット技術などのIT関連サービス、KONOIKEグループ既存および新規顧客への提案と導入推進

### ![](https://mypage.r-agent.com/_next/static/media/map-pin.9a33d316.svg)本社所在地

〒104-0033 東京都中央区新川２－３－１セントラルスクエア４Ｆ

### ![](https://mypage.r-agent.com/_next/static/media/office-location.d086d77a.svg)本社以外の事務所

### ![](https://mypage.r-agent.com/_next/static/media/goods.a1378b84.svg)事業内容・商品・販売先等

・KONOIKEグループ全社向けのシステム企画、設計、プロジェクト管理、導入展開 ・KONOIKEグループ既存および新規顧客への提案と推進導入

### ![](https://mypage.r-agent.com/_next/static/media/office-location2.8bd333ac.svg)関連会社

鴻池運輸株式会社、株式会社NSD

### ![](https://mypage.r-agent.com/_next/static/media/chart.007bfb75.svg)株式公開

非公開

### ![](https://mypage.r-agent.com/_next/static/media/graph.0c713b91.svg)決算情報

### ![](https://mypage.r-agent.com/_next/static/media/pie-chart.2225a4fb.svg)外資比率

### ![](https://mypage.r-agent.com/_next/static/media/url-company.bf923580.svg)企業URL

[https://kits-konoike.net/](https://kits-konoike.net/)