株式会社博報堂ＳＹＮＶＯＩＣＥ

# 【構築・運用保守エンジニア】自社プロダクトの構築・納品・運用保守

450〜600万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間120日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

東京都品川区北品川4-7-35御殿山トラストタワー9F（2026年1月に水道橋、飯田橋に移転予定）

業界未経験OK

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

■AWS×Zabbixなど最先端技術を活用し戦略的なインフラ構築・運用に挑戦 ■自社プロダクト（通話録音・CTI等）の安定運用を支える ■運用に留まらず、課題解決や自動化・効率化を推進する攻めのエンジニア ■博報堂グループの安定基盤×裁量ある技術領域

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 職務内容

### ![](https://mypage.r-agent.com/_next/static/media/company.f695756d.svg)企業・求人の特色

博報堂傘下でボイスソリューションサービスを全国展開。

### ![](https://mypage.r-agent.com/_next/static/media/note.135161c5.svg)仕事内容

自社プロダクト（通話録音, CTI等）の構築からお客様に納品及び運用保守までを行います。顧客の疑問や課題解決を通じ、製品の価値を高め、信頼と高い満足度を創造する重要なミッションです。 お客様が安心してご利用いただけるよう、導入からトラブル解決まで最前線で活躍していただきます。 - 注文要件に基づくプロダクト初期セットアップ、ハードウェアのキッティング業務 - 導入プロダクトに応じた機器設置などの現地作業（休出あり、代休取得可）、パートナーへの技術支援と進捗管理（リモート） - お客様からの電話・メールによる技術的な問い合わせ、操作方法のサポート・障害の原因究明/課題解決対応

### ![](https://mypage.r-agent.com/_next/static/media/experience.b0f16c1a.svg)求める能力・経験

【いずれか必須】Linux（CentOS/AlmaLinux等）のコマンド操作を含む運用知識と実務経験。技術的な問い合わせ、操作サポート、障害対応経験。または、ネットワークインフラの設計・構築経験。 【歓迎】 - 通話録音システムの導入に伴うPBX/ネットワークに関する基礎知識 - 現場の多様なタスクに対し、優先順位をつけて、柔軟かつ着実に対応できる実行力 - 自律的に学び続けスキルアップを図り、ノウハウをチームに還元し課題解決を推進できる実行力の高い方 【勤務条件】　出社ベースでの勤務。出張に抵抗のない方。

学歴

高校、専修、短大、高専、大学、大学院

## 勤務条件

### ![](https://mypage.r-agent.com/_next/static/media/employ.e9939c19.svg)雇用形態

正社員（期間の定め：無）

試用期間

有 3ヶ月（試用期間中の勤務条件：変更無）

### ![](https://mypage.r-agent.com/_next/static/media/money.8ec98a5a.svg)給与

450万円～600万円 月給制 月給 321,428円～428,571円 月給￥321,428〜￥428,571 基本給￥277,992〜￥370,656 諸手当￥43,436〜￥57,915を含む/月 ■賞与実績:2か月分

通勤手当

会社規定に基づき支給

### ![](https://mypage.r-agent.com/_next/static/media/working-time.c8e50ef1.svg)勤務時間

08時間00分 休憩60分

09:00～18:00

残業

有 平均残業時間：20時間

残業手当

有 残業時間に応じて別途支給

### ![](https://mypage.r-agent.com/_next/static/media/holiday.c0f9fa3c.svg)休日・休暇

年間 120日 内訳：完全週休二日制、土曜 日曜 祝日、夏期5日、年末年始6日

有給休暇

入社半年経過時点10日 最高付与日数20日

### ![](https://mypage.r-agent.com/_next/static/media/heart.a433f583.svg)社会保険

健康保険：有 厚生年金：有 雇用保険：有 労災保険：有

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

■業務内容の変更の範囲：インフラ・ソリューション事業に関する業務全般。本人の成長と適性に応じて、技術スペシャリストやチームリーダーへの役割変更を含む、当社が定める業務への異動。 ■就業場所の変更の範囲：変更無し ■取扱禁止業務が含まれないか「職業安定法 第32条の11（取扱職業の範囲）」 →※建物の改変を伴う業務は含まない

最短２タップで完了!

応募する

興味なし

## 勤務地

### ![](https://mypage.r-agent.com/_next/static/media/position.3ff6801a.svg)配属先

### ![](https://mypage.r-agent.com/_next/static/media/relocation.5099e075.svg)転勤

無

### ![](https://mypage.r-agent.com/_next/static/media/map.9a33d316.svg)株式会社博報堂SYNVOICE

住所

東京都品川区北品川4-7-35御殿山トラストタワー9F（2026年1月に水道橋、飯田橋に移転予定）

最寄駅

JR山手線品川駅 JR山手線大崎駅 京浜急行電鉄京急本線北品川駅

喫煙環境

屋内禁煙（屋内喫煙可能場所あり）

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

## 制度・福利厚生

### ![](https://mypage.r-agent.com/_next/static/media/heart-hand.782dcdb8.svg)制度

在宅勤務（一部従業員利用可） リモートワーク可（一部従業員利用可） 自転車通勤可（全従業員利用可） 服装自由（全従業員利用可） 出産・育児支援制度（全従業員利用可） 資格取得支援制度（全従業員利用可）

### ![](https://mypage.r-agent.com/_next/static/media/another.84c25cb6.svg)その他

寮・社宅

無

退職金

有

### ![](https://mypage.r-agent.com/_next/static/media/note-heart.134d7562.svg)制度備考

役職手当、住宅手当、扶養手当、在宅勤務、勉強会開催　他


株式会社博報堂ＳＹＮＶＯＩＣＥ

# 【構築・運用保守エンジニア】自社プロダクトの構築・納品・運用保守

450〜600万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間120日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

東京都品川区北品川4-7-35御殿山トラストタワー9F（2026年1月に水道橋、飯田橋に移転予定）

業界未経験OK

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

■AWS×Zabbixなど最先端技術を活用し戦略的なインフラ構築・運用に挑戦 ■自社プロダクト（通話録音・CTI等）の安定運用を支える ■運用に留まらず、課題解決や自動化・効率化を推進する攻めのエンジニア ■博報堂グループの安定基盤×裁量ある技術領域

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 選考内容

### ![](https://mypage.r-agent.com/_next/static/media/people.a9317f75.svg)採用人数

1名

### ![](https://mypage.r-agent.com/_next/static/media/interview.979de149.svg)面接回数

2～3回

### ![](https://mypage.r-agent.com/_next/static/media/papers.2b11ca07.svg)選考

筆記試験：無

## 企業概要

企業名

株式会社博報堂ＳＹＮＶＯＩＣＥ

代表取締役社長

金野　敏和

設立

1990年03月06日

従業員数

29名

資本金

22百万円

平均年齢

39.0歳

### ![](https://mypage.r-agent.com/_next/static/media/map-pin.9a33d316.svg)本社所在地

〒140-0001 東京都品川区北品川４－７－３５御殿山トラストタワー９階

### ![](https://mypage.r-agent.com/_next/static/media/office-location.d086d77a.svg)本社以外の事務所

### ![](https://mypage.r-agent.com/_next/static/media/goods.a1378b84.svg)事業内容・商品・販売先等

事業内容：ボイスソリューション事業 商品：通話録音、SMS、CTI、商談アプリ 販売先：銀行、証券、自動車ディーラー　など

### ![](https://mypage.r-agent.com/_next/static/media/office-location2.8bd333ac.svg)関連会社

### ![](https://mypage.r-agent.com/_next/static/media/chart.007bfb75.svg)株式公開

非公開

主な株主

株式会社博報堂 100.0％

### ![](https://mypage.r-agent.com/_next/static/media/graph.0c713b91.svg)決算情報

|決算期|   |売上高|経常利益|
|---|---|---|---|
|前々期|2023年12月|432百万円|-28百万円|
|前期|2024年12月|411百万円|-11百万円|
|今期予測|2025年12月|700百万円|34百万円|

※単体決算

### ![](https://mypage.r-agent.com/_next/static/media/pie-chart.2225a4fb.svg)外資比率

0.0％

### ![](https://mypage.r-agent.com/_next/static/media/url-company.bf923580.svg)企業URL

[https://www.synvoice.co.jp/](https://www.synvoice.co.jp/)