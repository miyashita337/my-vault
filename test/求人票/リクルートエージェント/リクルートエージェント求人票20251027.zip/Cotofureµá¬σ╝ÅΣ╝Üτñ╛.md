Ｃｏｔｏｆｕｒｅ株式会社

# 【AI開発エンジニア・システム開発エンジニア】第2新卒歓迎/自社内開発

400〜700万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間120日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

東京都千代田区神田須田町2丁目1-1　MA SQUARE AKIHABARA 8F

業界未経験OK

フレックス勤務

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

AI領域に強みを持ち、大型受託開発案件にプライムベンダーとして参画中◎ AIを組み合わせた次世代のサービス開発を手掛けています。社内エンジニアとして世の中のニーズに応える開発をお任せできるエンジニアを募集しております。

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 職務内容

### ![](https://mypage.r-agent.com/_next/static/media/company.f695756d.svg)企業・求人の特色

「すべての人々に愛(AI)を。より豊かで便利な世界を提供し、人生が変わる瞬間をもたらす」というMissionを掲げ、組織拡大と事業基盤の強化を進めています。成長フェーズの今だからこそ、会社づくりや事業の成長過程にも深く関われます。

### ![](https://mypage.r-agent.com/_next/static/media/note.135161c5.svg)仕事内容

AIと組み合わせた次世代のサービスを開発しており、社内エンジニアとして自社内開発をメインで担うエンジニアを募集します。 画像認識や話者認識などのAIを活用した開発に携わっていただきます。 担当プロジェクトについては、経験やスキル、ご希望などを考慮した上で決定いたします。

### ![](https://mypage.r-agent.com/_next/static/media/experience.b0f16c1a.svg)求める能力・経験

・何らかのシステム、アプリ、AIの開発に携わったことのある方 ※経験年数が浅くても、開発の流れを理解している方であればOKです。 ※言語やAIに関わった開発経験は問いません。AIに特化したご経験がなくても、 これまでのエンジニアとしてのご経験を活かしたい方を募集しております。 【歓迎する経験・スキル（必須ではありません）】・PythonやAWSを使った業務経験のある方・AI関連のプロジェクトに携わったことのある方・モバイルアプリ（iOS/Android）の開発経験をお持ちの方・画像や動画処理を活かした製品やサービスの開発経験をお持ちの方・リーダー・マネージャー経験のある方・第二新卒歓迎、社会人経験10年以上歓迎

学歴

専修、大学、大学院

## 勤務条件

### ![](https://mypage.r-agent.com/_next/static/media/employ.e9939c19.svg)雇用形態

正社員（期間の定め：無）

試用期間

有 6ヶ月（試用期間中の勤務条件：変更無）

### ![](https://mypage.r-agent.com/_next/static/media/money.8ec98a5a.svg)給与

400万円～700万円 月給制 月給 300,000円～540,000円 月給￥300,000〜￥540,000 基本給￥200,000〜￥400,000 固定残業代￥80,000〜￥140,000を含む/月 ■賞与実績:年1回

通勤手当

会社規定に基づき支給

### ![](https://mypage.r-agent.com/_next/static/media/working-time.c8e50ef1.svg)勤務時間

07時間30分 休憩60分

フレックスタイム制

有 コアタイム：有 11:00～16:00

残業

有

残業手当

有 固定残業代制 超過分別途支給 固定残業代の相当時間：40.0時間/月

### ![](https://mypage.r-agent.com/_next/static/media/holiday.c0f9fa3c.svg)休日・休暇

年間 120日 内訳：完全週休二日制、土曜 日曜 祝日

有給休暇

入社半年経過時点10日 最高付与日数20日

その他

その他（夏季休暇、年末年始休暇、慶弔休暇）

### ![](https://mypage.r-agent.com/_next/static/media/heart.a433f583.svg)社会保険

健康保険：有 厚生年金：有 雇用保険：有 労災保険：有

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

※理論年収となります。 ※想定年収・月給は固定残業時間40時間0分/月を含み超過分は全額支給します。 ※選考を通じて上記想定年収内で上下する可能性があり、前職やこれまでのご経験、スキルを考慮して決定いたします。 【フレックスタイム制】有 ※フレックスタイム制（コアタイム有/フレキシブルタイム有）を導入しています。 ＜標準的な労働時間＞10:00〜18:30（休憩：12:00〜13:00） その他補足事項 1) 従事すべき業務の変更の範囲 　 変更の範囲：会社内での全ての業務 2) 就業場所の変更の範囲 　 変更の範囲：会社の定める事業所および場所（テレワークを行う場所を含む）

最短２タップで完了!

応募する

興味なし

## 勤務地

### ![](https://mypage.r-agent.com/_next/static/media/position.3ff6801a.svg)配属先

AI&DXテクノロジー開発部

### ![](https://mypage.r-agent.com/_next/static/media/relocation.5099e075.svg)転勤

当面無

### ![](https://mypage.r-agent.com/_next/static/media/map.9a33d316.svg)本社

住所

東京都千代田区神田須田町2丁目1-1　MA SQUARE AKIHABARA 8F

最寄駅

JR山手線秋葉原駅 JR山手線神田駅 東京メトロ丸ノ内線淡路町駅

喫煙環境

屋内全面禁煙

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

テレワーク有（自宅）（リモートワーク:週1〜3日、社内ルールに準ずる）

## 制度・福利厚生

### ![](https://mypage.r-agent.com/_next/static/media/heart-hand.782dcdb8.svg)制度

リモートワーク可（全従業員利用可） 服装自由（全従業員利用可）

### ![](https://mypage.r-agent.com/_next/static/media/another.84c25cb6.svg)その他

寮・社宅

無

退職金

無

### ![](https://mypage.r-agent.com/_next/static/media/note-heart.134d7562.svg)制度備考

■フリードリンク：オフィスの冷蔵庫に、業務中に自由に飲めるドリンクを設置しています！ （例）お水、お茶、炭酸飲料、コーヒー、etc... ■フリーアドレス制：席を固定していないので、その日の気分にあわせて仕事をすることができます！標準始業時間が朝10時以降遅めの始業時間なので、混雑する満員電車を避けて通勤することができます！服装自由ベンチャー企業なので、働きやすさを重視しているため服装は自由です！ ■スマートフォン貸与：社用携帯として、スマートフォンを貸与します！ ■テレワーク導入（週1〜3日） 【教育制度・資格補助補足】 ■資格取得補助/書籍購入負担 ■インフルエンザ予防接種(全額補助) ■ストックオプション制度あり ■参加自由の社員イベント有（野球観戦、バーベキュー、懇親会　など）

Ｃｏｔｏｆｕｒｅ株式会社

# 【AI開発エンジニア・システム開発エンジニア】第2新卒歓迎/自社内開発

400〜700万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間120日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

東京都千代田区神田須田町2丁目1-1　MA SQUARE AKIHABARA 8F

業界未経験OK

フレックス勤務

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

AI領域に強みを持ち、大型受託開発案件にプライムベンダーとして参画中◎ AIを組み合わせた次世代のサービス開発を手掛けています。社内エンジニアとして世の中のニーズに応える開発をお任せできるエンジニアを募集しております。

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 選考内容

### ![](https://mypage.r-agent.com/_next/static/media/people.a9317f75.svg)採用人数

1名

### ![](https://mypage.r-agent.com/_next/static/media/interview.979de149.svg)面接回数

2～3回

### ![](https://mypage.r-agent.com/_next/static/media/papers.2b11ca07.svg)選考

筆記試験：無 適性テスト有

## 企業概要

企業名

Ｃｏｔｏｆｕｒｅ株式会社

代表取締役社長ＣＥＯ

高橋　豊志

設立

2015年06月

従業員数

20名

資本金

200百万円

平均年齢

-

当社は「すべての人々に愛(AI)を。より豊かで便利な世界を提供し、人生が変わる瞬間をもたらす」というMissionを掲げ、様々な業種や業界の方と協力し、サービスを開発・提供してまいりました。また、当社では、AIを活用した下記のプロダクトをご提供・紹介しております。各AIプロダクトは、パッケージ製品だけではなくお客様のニーズに合わせてカスタマイズも可能です。 （例）「画像認識」画像や動画データから特徴をつかみ、対象物を識別するパターン認識技術の一つです。コンピュータが画像に映っている対象物の特徴（形や大きさ、数、色など）を大量に分析、理解させることで、対象物を推測させることができます。このコンピュータに対象物を理解をさせる行為を「学習」と呼び、大量のデータをコンピュータに理解させていくことで、精度が向上します。画像認識は人工知能（AI）におけるディープラーニング技術により、日々発展を遂げています。この技術を利用することで、顔認証や骨格検知、モザイク加工、姿勢検知、笑顔検知など幅広い画像認識に対応しています。画像認識を利用することで、顔認証システムや不審者検知、文字認識（OCR）、不適切画像の検出、骨格推定、工場でのイレギュラー検知など幅広い分野で活用することができます

### ![](https://mypage.r-agent.com/_next/static/media/map-pin.9a33d316.svg)本社所在地

〒101-0041 東京都千代田区神田須田町２－１－１MA SQUARE AKIHABARA８Ｆ

### ![](https://mypage.r-agent.com/_next/static/media/office-location.d086d77a.svg)本社以外の事務所

### ![](https://mypage.r-agent.com/_next/static/media/goods.a1378b84.svg)事業内容・商品・販売先等

1. AIプロダクト・システム開発事業 2. 各種ソフトウェア・システム開発事業 3. DX支援事業

### ![](https://mypage.r-agent.com/_next/static/media/office-location2.8bd333ac.svg)関連会社

### ![](https://mypage.r-agent.com/_next/static/media/chart.007bfb75.svg)株式公開

非公開

### ![](https://mypage.r-agent.com/_next/static/media/graph.0c713b91.svg)決算情報

### ![](https://mypage.r-agent.com/_next/static/media/pie-chart.2225a4fb.svg)外資比率

### ![](https://mypage.r-agent.com/_next/static/media/url-company.bf923580.svg)企業URL

[https://www.cotofure.com/](https://www.cotofure.com/)