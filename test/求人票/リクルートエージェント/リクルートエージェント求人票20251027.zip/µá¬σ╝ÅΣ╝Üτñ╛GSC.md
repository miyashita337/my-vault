株式会社ＧＳＣ

# 【関西/管理職候補】システムエンジニア/受託開発/アプリインフラ開発経験歓迎

720〜1200万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間125日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

大阪府大阪市淀川区西中島5-2-5 中島第2ビル6F

業界未経験OK

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

【大阪】システムエンジニア職の経験者向け求人/増員採用！ ■今後業務拡大を予定しており、増員の採用を行います。■6月にオフィス改築！カフェスペースや畳の設置など綺麗な場所で快適に働けます〇

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 職務内容

### ![](https://mypage.r-agent.com/_next/static/media/company.f695756d.svg)企業・求人の特色

■お客様の問題や課題を「システムコンサルティング」「システムエンジニアリングサービス」「ソフトウェア開発」を通じ最善の解決策をご提案します。外部機関が加入し、グローバルスタンダードな教育が受けられます！！

### ![](https://mypage.r-agent.com/_next/static/media/note.135161c5.svg)仕事内容

事業拡大に伴い管理職候補募集中です。 ITエンジニア、システムエンジニア、プログラマーとして受託業務またはSES業務をお任せいたします！ 本人の経験、適性、希望などを考慮して最適な案件・フェーズにアサインします。 ★point★技術者にもインセンティブ制度を導入しております

### ![](https://mypage.r-agent.com/_next/static/media/experience.b0f16c1a.svg)求める能力・経験

【推奨スキル】クラウド設計、構築、移行経験5年以上(AWS,OCI,GCP,Azure) ★案件拡大により経験者の方増員募集！★ 【求める人物像】円滑にコミュニケーションを取れ、ミスなく着実に業務をこなせる方 ■「お客様にも従業員にも選ばれる続ける企業」であるため、社内の改革も大幅に進めております。オフィス改装や、評価制度の構築、事業の拡大など、3年〜5年を目安に様々なプロジェクトを進めております。 ■勤務地：フルリモート相談可/月に数回出社の可能性あり

学歴

高校、専修、短大、高専、大学、大学院

## 勤務条件

### ![](https://mypage.r-agent.com/_next/static/media/employ.e9939c19.svg)雇用形態

正社員（期間の定め：無）

試用期間

有 3ヶ月（試用期間中の勤務条件：変更無）

### ![](https://mypage.r-agent.com/_next/static/media/money.8ec98a5a.svg)給与

720万円～1,200万円 月給制 月給 600,000円～1,000,000円 月給￥600,000〜￥1,000,000 基本給￥600,000〜￥1,000,000を含む/月

通勤手当

会社規定に基づき支給

### ![](https://mypage.r-agent.com/_next/static/media/working-time.c8e50ef1.svg)勤務時間

08時間00分 休憩45分

09:00～17:45

残業

有 平均残業時間：20時間

残業手当

有 残業時間に応じて別途支給

### ![](https://mypage.r-agent.com/_next/static/media/holiday.c0f9fa3c.svg)休日・休暇

年間 125日 内訳：完全週休二日制、土曜 日曜 祝日

有給休暇

入社半年経過時点10日

その他

その他（年末年始/夏季/慶弔/結婚 等）

### ![](https://mypage.r-agent.com/_next/static/media/heart.a433f583.svg)社会保険

健康保険：有 厚生年金：有 雇用保険：有 労災保険：有

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

プロジェクトの内容によっては異なる場合があります。 業務内容の変更の範囲　当社業務全般 就業場所の変更の範囲　本社及び全国のクライアント先

最短２タップで完了!

応募する

興味なし

## 勤務地

### ![](https://mypage.r-agent.com/_next/static/media/position.3ff6801a.svg)配属先

事業拡大に伴う増員採用となります。

### ![](https://mypage.r-agent.com/_next/static/media/relocation.5099e075.svg)転勤

無

### ![](https://mypage.r-agent.com/_next/static/media/map.9a33d316.svg)本社

住所

大阪府大阪市淀川区西中島5-2-5 中島第2ビル6F

喫煙環境

屋内全面禁煙

### ![](https://mypage.r-agent.com/_next/static/media/noteAndPen.a60984d2.svg)備考

※一部常駐案件あり　※フルリモート相談可/月に数回出社の可能性あり

## 制度・福利厚生

### ![](https://mypage.r-agent.com/_next/static/media/heart-hand.782dcdb8.svg)制度

### ![](https://mypage.r-agent.com/_next/static/media/another.84c25cb6.svg)その他

寮・社宅

無

退職金

無

その他制度

・昇給年(1回)・賞与年(2回)・健康診断(年1回)

### ![](https://mypage.r-agent.com/_next/static/media/note-heart.134d7562.svg)制度備考


株式会社ＧＳＣ

# 【関西/管理職候補】システムエンジニア/受託開発/アプリインフラ開発経験歓迎

720〜1200万

![](https://mypage.r-agent.com/_next/static/media/calendar.1c34b908.svg)休日

年間125日

![](https://mypage.r-agent.com/_next/static/media/address_stroke.2de2d768.svg)勤務地

大阪府大阪市淀川区西中島5-2-5 中島第2ビル6F

業界未経験OK

年間休日120日以上

土曜出勤なし

日曜出勤なし

残業手当あり

正社員

おすすめ企業オファーは、企業が「ぜひ応募してほしい」と考える人物像にマッチした方だけにお届けする特別なオファーです。

求人のおすすめポイント

![](https://mypage.r-agent.com/_next/static/media/ca.67595796.png)

【大阪】システムエンジニア職の経験者向け求人/増員採用！ ■今後業務拡大を予定しており、増員の採用を行います。■6月にオフィス改築！カフェスペースや畳の設置など綺麗な場所で快適に働けます〇

※リクルートエージェントの取材情報です。掲載企業からの情報ではありません。

最短２タップで完了!

応募する

#### 募集要項

#### 選考・企業概要

## 選考内容

### ![](https://mypage.r-agent.com/_next/static/media/people.a9317f75.svg)採用人数

3名

### ![](https://mypage.r-agent.com/_next/static/media/interview.979de149.svg)面接回数

1～2回

### ![](https://mypage.r-agent.com/_next/static/media/papers.2b11ca07.svg)選考

筆記試験：無

## 企業概要

企業名

株式会社ＧＳＣ

代表取締役

伊勢谷　圭治

設立

2003年05月

従業員数

40名

資本金

10百万円

平均年齢

-

【当社について】 ■大阪府大阪市淀川区にて、システムコンサルティング、システムエンジニアリングサービス、ソフトウェア開発を手掛けています。 ■「システムコンサルティング」では、企業経営の視点からIT戦略の策定やITを活用した業務改革の計画・実行支援など、企業のIT活用力の向上を支援しています。多くの実績を保有し、蓄積したノウハウを活用することで、IT活用力の向上に取り組んでいます。 ■「システムエンジニアリングサービス」では、急な増員や深い知識・経験を持つ技術者不足など、規模・期間に関わらずお客様のご要望に応じて最適な人材を提案しています。 ■「ソフトウェア開発」では、基幹系システム、WEBシステムなど多種多様な開発を手掛けており、培ってきたノウハウと確かな技術力により、高品質なシステムを提供しています。

### ![](https://mypage.r-agent.com/_next/static/media/map-pin.9a33d316.svg)本社所在地

〒532-0011 大阪府大阪市淀川区西中島５丁目２－５中島第２ビル６階

### ![](https://mypage.r-agent.com/_next/static/media/office-location.d086d77a.svg)本社以外の事務所

〒530-0011 大阪府大阪市北区大深町1-1 ヨドバシ梅田タワー 8F WeWork

### ![](https://mypage.r-agent.com/_next/static/media/goods.a1378b84.svg)事業内容・商品・販売先等

システムコンサルティング/システムエンジニアリングサービス/ソフトウェア開発

### ![](https://mypage.r-agent.com/_next/static/media/office-location2.8bd333ac.svg)関連会社

### ![](https://mypage.r-agent.com/_next/static/media/chart.007bfb75.svg)株式公開

非公開

### ![](https://mypage.r-agent.com/_next/static/media/graph.0c713b91.svg)決算情報

### ![](https://mypage.r-agent.com/_next/static/media/pie-chart.2225a4fb.svg)外資比率

### ![](https://mypage.r-agent.com/_next/static/media/url-company.bf923580.svg)企業URL

[http://www.gsc.ecnet.jp](http://www.gsc.ecnet.jp/)